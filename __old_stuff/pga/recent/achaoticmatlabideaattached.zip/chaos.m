% chaos.m

x = 0.12345; y = 0.6789;

for i = 1:1000
	[x,y] = squeezer(x,y);
	printf( "%10.7f %10.7f\n" , x, y );
end;
